import * as actions from './action.js'
import CONSTANTS from '../../core/utils/constants';


const store = {
    state: {
    },

    mutations: {
        
    },
    actions,
    getters: {
    }
};

export default store;
