import * as actions from './actions'
import CONSTANTS from '../../core/utils/constants';


const store = {
    state: {
        loading:false
    },

    mutations: {
       
    },
    actions,
    getters: {
    }
};

export default store;
